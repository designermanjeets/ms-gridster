import { Component } from '@angular/core';

export interface Tile {
  color: string;
  cols?: number;
  rows?: number;
  text: string;
  w: number;
  h?: number;
  x: number;
  y?: number;
}

@Component({
  selector: 'zworkspace-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {

  title = 'zgridster';
  
  tiles: Tile[] = [
    { text: '1', color: 'lightblue', w: 1, x: 3 },
    { text: '2', color: 'lightgreen', w: 2, x: 2 },
    { text: '3', color: 'lightpink', w: 1, x: 1 },
    { text: '4', color: '#DDBDF1', w: 1, x: 4 },
    { text: '5', color: 'lightpink', w: 1, x: 5 },
    { text: '6', color: 'lightblue', w: 1, x: 6 },
    { text: '7', color: 'lightgreen', w: 1, x: 7 },
    { text: '8', color: 'lightblue', w: 1, x: 8 },
    { text: '9', color: '#DDBDF1', w: 1, x: 9 },
    { text: '10', color: 'lightgreen', w: 1, x: 10 },
    { text: '11', color: 'lightblue', w: 1, x: 11 },
    { text: '12', color: '#DDBDF1', w: 1, x: 12 },
  ];

  msconfig = {
    styleClass: ['border-rad-5'],
    dragNDrop: {
      cdkDragDisabled: false,
      cdkDragHandle: false,
    },
    responsive: {
      cols_lg: 10,
      cols_md: 8,
      cols_sm: 6,
      cols_xs: 2,
      custom: [
        {
          breakpoint: '(min-width: 600px) and (max-width: 659.98px)',
          cols: 3,
        },
      ],
    },
    flex: {
      gap: 10,
    },
  };

}
