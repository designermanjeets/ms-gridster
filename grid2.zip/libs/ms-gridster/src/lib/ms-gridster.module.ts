import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MsGridsterComponent } from './ms-gridster/ms-gridster.component';
import { ResizableComponent } from './resizable/resizable.component';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { MatGridListModule } from '@angular/material/grid-list';


@NgModule({
  imports: [CommonModule, DragDropModule, MatGridListModule],
  declarations: [MsGridsterComponent, ResizableComponent],
  exports: [MsGridsterComponent]
})
export class MsGridsterModule {}
