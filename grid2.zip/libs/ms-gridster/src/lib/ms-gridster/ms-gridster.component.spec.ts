import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MsGridsterComponent } from './ms-gridster.component';

describe('MsGridsterComponent', () => {
  let component: MsGridsterComponent;
  let fixture: ComponentFixture<MsGridsterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MsGridsterComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(MsGridsterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
