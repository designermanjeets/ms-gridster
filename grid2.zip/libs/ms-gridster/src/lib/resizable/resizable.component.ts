import { CdkDragEnd, CdkDragMove } from '@angular/cdk/drag-drop';
import {
  Component,
  ChangeDetectionStrategy,
  ElementRef,
  Output,
  EventEmitter,
  NgZone,
  OnInit,
  OnDestroy,
} from '@angular/core';
import { Subject, merge, of } from 'rxjs';
import { tap, auditTime, withLatestFrom } from 'rxjs/operators';
import { ResizedEvent } from '../_directives/resized.event';

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: '[msresizable]',
  template: `
    <ng-content></ng-content>
    <div class="resizable-handle" cdkDrag 
      (cdkDragStarted)="dragStarted()" 
      (cdkDragEnded)="dragEnded($event)" 
      (cdkDragMoved)="dragMoved($event)"></div>
    <div class="resizable-triangle" *ngIf="sub$ | async"></div>
  `,
  styleUrls: ['./resizable.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ResizableComponent implements OnInit, OnDestroy {

  startClientRect: any;

  private observer: ResizeObserver;
  private oldRect?: DOMRectReadOnly;
  @Output() resized = new EventEmitter<ResizedEvent>();

  private startSize$ = new Subject<DOMRect>();
  private dragMove$ = new Subject<CdkDragMove>();
  private dragMoveAudited$ = this.dragMove$.pipe(
    withLatestFrom(this.startSize$),
    auditTime(16),
    tap(([{ distance }, rect]) => {
      this.el.nativeElement.style.width = `${rect.width + distance.x}px`;
      this.el.nativeElement.style.height = `${rect.height + distance.y}px`;
    })
  );

  sub$ = merge(this.dragMoveAudited$, of(true));

  constructor(
    private el: ElementRef<HTMLElement>,
    private readonly zone: NgZone
  ) {
    this.resized = new EventEmitter<ResizedEvent>();
    this.observer = new ResizeObserver((entries) =>
      this.zone.run(() => this.observe(entries))
    );
  }

  dragStarted(): void {
    this.startSize$.next(this.el.nativeElement.getBoundingClientRect());
    this.startClientRect = this.el.nativeElement.getBoundingClientRect();
  }

  dragEnded($event: CdkDragEnd): void {
    $event.source._dragRef.reset();
    console.log(this.el.nativeElement.getAttribute('ms-w'));
    console.log(this.startClientRect);
    console.log(this.el.nativeElement.getBoundingClientRect());
    const singleColWidth = this.startClientRect.width/Number(this.el?.nativeElement?.getAttribute('ms-w'));
    const widthDifferance = (this.el.nativeElement.getBoundingClientRect().width) - this.startClientRect.width;
    console.log(singleColWidth);
    console.log(widthDifferance);
    const value1 = this.startClientRect.width;
    const value2 = Math.round(singleColWidth/widthDifferance);
    this.el.nativeElement.style.width = value1 + (singleColWidth*value2)+'px';
    console.log(value1 + (singleColWidth*value2)+'px')
    this.el.nativeElement.setAttribute('ms-w', '5')
  }

  dragMoved($event: CdkDragMove): void {
    this.dragMove$.next($event);
  }

  public ngOnInit(): void {
    this.observer.observe(this.el.nativeElement);
  }

  public ngOnDestroy(): void {
    this.observer.disconnect();
  }

  private observe(entries: ResizeObserverEntry[]): void {
    const domSize = entries[0];
    const resizedEvent = new ResizedEvent(domSize.contentRect, this.oldRect);
    this.oldRect = domSize.contentRect;
    this.resized.emit(resizedEvent);
  }
}
