import { Component } from '@angular/core';

export interface Tile {
  color: string;
  cols?: number;
  rows?: number;
  text: string;
}

@Component({
  selector: 'zworkspace-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {

  title = 'zgridster';
  
  tiles: Tile[] = [
    { text: '1', color: 'lightblue' },
    { text: '2', color: 'lightgreen' },
    { text: '3', color: 'lightpink' },
    { text: '4', color: '#DDBDF1' },
    { text: '5', color: 'lightpink' },
    { text: '6', color: 'lightblue' },
    { text: '7', color: 'lightgreen' },
    { text: '8', color: 'lightblue' },
    { text: '9', color: '#DDBDF1' },
    { text: '10', color: 'lightgreen' },
    { text: '11', color: 'lightblue' },
    { text: '12', color: '#DDBDF1' },
  ];

  msconfig = {
    styleClass: ['border-rad-5'],
    dragNDrop: {
      cdkDrag: true,
      cdkDragDisabled: false,
      cdkDragHandle: false,
    },
    responsive: {
      cols_lg: 10,
      cols_md: 8,
      cols_sm: 6,
      cols_xs: 2,
      custom: [
        {
          breakpoint: '(min-width: 600px) and (max-width: 659.98px)',
          cols: 4,
        },
      ],
    },
    flex: {
      gap: 10,
    },
  };

}
