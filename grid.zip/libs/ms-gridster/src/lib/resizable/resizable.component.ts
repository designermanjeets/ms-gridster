import { CdkDragEnd, CdkDragMove } from '@angular/cdk/drag-drop';
import {
  Component,
  ChangeDetectionStrategy,
  ElementRef,
  Output,
  EventEmitter,
  NgZone,
  OnInit,
  OnDestroy,
} from '@angular/core';
import { Subject, merge, of } from 'rxjs';
import { tap, auditTime, withLatestFrom } from 'rxjs/operators';
import { ResizedEvent } from '../_directives/resized.event';

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: '[msresizable]',
  template: `
    <ng-content></ng-content>
    <div class="resizable-handle" cdkDrag 
      (cdkDragStarted)="dragStarted()" 
      (cdkDragEnded)="dragEnded($event)" 
      (cdkDragMoved)="dragMoved($event)"></div>
    <div class="resizable-triangle" *ngIf="sub$ | async"></div>
  `,
  styleUrls: ['./resizable.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ResizableComponent implements OnInit, OnDestroy {
  private observer: ResizeObserver;
  private oldRect?: DOMRectReadOnly;
  @Output() resized = new EventEmitter<ResizedEvent>();

  private startSize$ = new Subject<DOMRect>();
  private dragMove$ = new Subject<CdkDragMove>();
  private dragMoveAudited$ = this.dragMove$.pipe(
    withLatestFrom(this.startSize$),
    auditTime(16),
    tap(([{ distance }, rect]) => {
      this.el.nativeElement.style.width = `${rect.width + distance.x}px`;
      this.el.nativeElement.style.height = `${rect.height + distance.y}px`;
    })
  );

  sub$ = merge(this.dragMoveAudited$, of(true));

  constructor(
    private el: ElementRef<HTMLElement>,
    private readonly zone: NgZone
  ) {
    this.resized = new EventEmitter<ResizedEvent>();
    this.observer = new ResizeObserver((entries) =>
      this.zone.run(() => this.observe(entries))
    );
  }

  dragStarted(): void {
    this.startSize$.next(this.el.nativeElement.getBoundingClientRect());
  }

  dragEnded($event: CdkDragEnd): void {
    $event.source._dragRef.reset();
    console.log($event)
    // this.el.nativeElement.style.width = `${Math.round($event.distance.x/100)}px`;-
  }

  dragMoved($event: CdkDragMove): void {
    this.dragMove$.next($event);
  }

  public ngOnInit(): void {
    this.observer.observe(this.el.nativeElement);
  }

  public ngOnDestroy(): void {
    this.observer.disconnect();
  }

  private observe(entries: ResizeObserverEntry[]): void {
    const domSize = entries[0];
    const resizedEvent = new ResizedEvent(domSize.contentRect, this.oldRect);
    this.oldRect = domSize.contentRect;
    this.resized.emit(resizedEvent);
  }
}
