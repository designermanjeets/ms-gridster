/* eslint-disable @typescript-eslint/no-explicit-any */
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  Input,
} from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { distinctUntilChanged, Observable, tap } from 'rxjs';

// const Breakpoints: { XSmall: string; Small: string; Medium: string; Large: string; XLarge: string; Handset: string; Tablet: string; Web: string; HandsetPortrait: string; TabletPortrait: string; WebPortrait: string; HandsetLandscape: string; TabletLandscape: string; WebLandscape: string; }; // From Material Dox

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'ms-gridster',
  templateUrl: './ms-gridster.component.html',
  styleUrls: ['./ms-gridster.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MsGridsterComponent implements AfterViewInit {

  @Input() tiles: any[] = [];
  @Input() msconfig: any = {};

  breakpoints: any;
  currentBreakpoint: any;
  caclColWidth: any;

  private breakpoint$: Observable<any> | undefined;

  constructor(
    private breakpointObserver: BreakpointObserver
  ) {

  }

  ngAfterViewInit() {

    this.breakpoints = Object.assign({}, ...Object.entries(Breakpoints).map(([a,b]) => ({ [b]: a })))
    this.msconfig.responsive?.custom.forEach((ele: any) => this.breakpoints[ele.breakpoint] = ele.cols);

    this.breakpoint$ = this.breakpointObserver
      .observe(this.getBreakpoints())
      .pipe(
        // tap((breakpoint) => console.log(breakpoint)),
        distinctUntilChanged()
      );

    this.breakpoint$.subscribe((breakpoint) => this.breakpointChanged(breakpoint));
  }

  private breakpointChanged(breakpoint: any) {

    Object.keys(this.breakpoints).map((key: any) => {
      if(breakpoint.breakpoints[key]) {
          this.currentBreakpoint = this.getBreakpointName(key);
          console.log(key)
          switch (this.currentBreakpoint) {
            case 'Large':
              this.caclColWidth = `calc(${ 100 / this.msconfig?.responsive.cols_lg }%  - ${this.msconfig?.flex?.gap * 2}px)`;
              break;
            case 'Medium':
              this.caclColWidth = `calc(${ 100 / this.msconfig?.responsive.cols_md }%  - ${this.msconfig?.flex?.gap * 2}px)`;
              break;
            case 'Small':
              this.caclColWidth = `calc(${ 100 / this.msconfig?.responsive.cols_sm }%  - ${this.msconfig?.flex?.gap * 2}px)`;
              break;
            case 'XSmall':
              this.caclColWidth = `calc(${ 100 / this.msconfig?.responsive.cols_xs }%  - ${this.msconfig?.flex?.gap * 2}px)`;
              break;
          }
          if(!isNaN(this.currentBreakpoint)) {
            console.warn('Custom Breakpoint Achieved!');
            this.caclColWidth = `calc(${ 100 / this.currentBreakpoint }%  - ${this.msconfig?.flex?.gap * 2}px)`;
          }
        }
    });

  }

  getBreakpoints(): string[] {
    return Object.keys(this.breakpoints);
  }

  getBreakpointName(breakpointValue: any): string {
    return this.breakpoints[breakpointValue];
  }

  drop(event: CdkDragDrop<string[]> | any) {
    moveItemInArray(this.tiles, event.previousIndex, event.currentIndex);
  }

  resized(event: any) {
    // console.log(event);
  }
}
